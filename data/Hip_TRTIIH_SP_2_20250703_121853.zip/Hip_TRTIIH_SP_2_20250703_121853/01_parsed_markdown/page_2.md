

# Trident II Clusterhole HA surgical protocol