

# Trident II Clusterhole HA surgical protocol

## Catalog information

### Trident Crossfire Polyethylene Inserts

<table>
  <thead>
    <tr>
      <th>Trident 0° Crossfire Inserts</th>
      <th>Trident 10° Crossfire Inserts</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>621-00-22A</td>
      <td>621-10-22A</td>
    </tr>
    <tr>
      <td>621-00-22B</td>
      <td>621-10-22B</td>
    </tr>
    <tr>
      <td>621-00-28C</td>
      <td>621-10-28C</td>
    </tr>
    <tr>
      <td>621-00-28D</td>
      <td>621-10-28D</td>
    </tr>
    <tr>
      <td>621-00-32D</td>
      <td>621-10-32D</td>
    </tr>
    <tr>
      <td>621-00-32E</td>
      <td>621-10-32E</td>
    </tr>
    <tr>
      <td>621-00-32F</td>
      <td>621-10-32F</td>
    </tr>
    <tr>
      <td>621-00-32G</td>
      <td>621-10-32G</td>
    </tr>
    <tr>
      <td>621-00-32H</td>
      <td>621-10-32H</td>
    </tr>
    <tr>
      <td>621-00-36E</td>
      <td>621-10-36E</td>
    </tr>
    <tr>
      <td>621-00-36F</td>
      <td>621-10-36F</td>
    </tr>
    <tr>
      <td>621-00-36G</td>
      <td>621-10-36G</td>
    </tr>
    <tr>
      <td>621-00-36H</td>
      <td>621-10-36H</td>
    </tr>
  </tbody>
</table>