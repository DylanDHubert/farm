

# Trident II Clusterhole HA surgical protocol

Figure 2a. Straight Reamer Handle (2102-0410)

Figure 2b. Offset Reamer Handle (T6320)

Figure 3. (2102-04xx) CuttingEdge Reamer Basket

## CuttingEdge Reamer Handle instructions

Figure 4.

Figure 4.
The reamer is attached to the reamer handle by pushing down and applying a quarter-turn to lock in place.

Figure 5.

Figure 5.
Removal of the reamer from the handle is performed by pulling back on the locking sleeve and rotating the reamer head a quarter-turn in a clockwise direction.