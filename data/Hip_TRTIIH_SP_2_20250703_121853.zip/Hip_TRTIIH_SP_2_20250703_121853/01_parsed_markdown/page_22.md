

# Trident II Clusterhole HA surgical protocol

## Catalog information

<table>
  <thead>
    <tr>
      <th colspan="2">Trident II Clusterhole HA Shell</th>
      <th colspan="2">6.5mm Low Profile Hex Screws</th>
      <th colspan="2">Hex Dome Hole Plug</th>
    </tr>
    <tr>
      <th>Catalog no.</th>
      <th>Size (mm)</th>
      <th>Catalog no.</th>
      <th>Size (mm)</th>
      <th>Catalog no.</th>
      <th>Size (mm)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>702-11-42A</td>
      <td>42</td>
      <td>7030-6515</td>
      <td>15mm</td>
      <td>7060-0000</td>
      <td>Hex Dome Hole Plug</td>
    </tr>
    <tr>
      <td>702-11-44B</td>
      <td>44</td>
      <td>7030-6520</td>
      <td>20mm</td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td>702-11-46C</td>
      <td>46</td>
      <td>7030-6525</td>
      <td>25mm</td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td>702-11-48D</td>
      <td>48</td>
      <td>7030-6530</td>
      <td>30mm</td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td>702-11-50D</td>
      <td>50</td>
      <td>7030-6535</td>
      <td>35mm</td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td>702-11-52E</td>
      <td>52</td>
      <td>7030-6540</td>
      <td>40mm</td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td>702-11-54E</td>
      <td>54</td>
      <td>7030-6545</td>
      <td>45mm</td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td>702-11-56F</td>
      <td>56</td>
      <td>7030-6550</td>
      <td>50mm</td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td>702-11-58F</td>
      <td>58</td>
      <td>7030-6555</td>
      <td>55mm</td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td>702-11-60G</td>
      <td>60</td>
      <td>7030-6560</td>
      <td>60mm</td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td>702-11-62G</td>
      <td>62</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td>702-11-64H</td>
      <td>64</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td>702-11-66H</td>
      <td>66</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
  </tbody>
</table>