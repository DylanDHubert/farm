# Page 9 (Enhanced)

*Enhanced on 2025-07-03 12:24:20*
*Document ID: Hip_TRTIIH_SP_2_20250703_121853*
*Enhancements applied: 1*

**Enhancement Notes:**
- General formatting and structure improvements

---

# Trident II Clusterhole HA Surgical Protocol

Figure 2a. Straight Reamer Handle (2102-0410)

Figure 2b. Offset Reamer Handle (T6320)

Figure 3. CuttingEdge Reamer Basket (2102-04xx)

## Instructions for Using the CuttingEdge Reamer Handle

Figure 4.

Figure 4.
The reamer is attached to the reamer handle by pushing down and applying a quarter-turn to lock in place.

Figure 5.

Figure 5.
Removal of the reamer from the handle is performed by pulling back on the locking sleeve and rotating the reamer head a quarter-turn in a clockwise direction.

**Note:** The markdown provided does not contain any tables to enhance. The text content has been preserved and the formatting has been cleaned up for better readability.
