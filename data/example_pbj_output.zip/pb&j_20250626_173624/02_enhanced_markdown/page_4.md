# Page 4 (Enhanced)

*Enhanced on 2025-06-26 17:36:37*
*Document ID: pb&j_20250626_173624*
*Enhancements applied: 1*

**Enhancement Notes:**
- Restructured document for better organization

---

# Bodega Test Page 1
## Instructions on Preparation of B.L.T. Sandwich

*This guide is for the preparation of a B.L.T. (Bacon, Lettuce, Tomato) sandwich.*

| Sandwich Size | Bacon (Oz) | Lettuce (Oz) | Tomato (Oz) |
| ------------- | ---------- | ------------ | ----------- |
| Small         | 0.5        | 1            | 1           |
| Medium        | 1          | 2            | 2           |
| Large         | 2.5        | 3            | 2           |

**NOTE:** Mayo is optional.
