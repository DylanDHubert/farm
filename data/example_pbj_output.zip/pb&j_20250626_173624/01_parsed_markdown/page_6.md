

# Bodega Test Page 3
## Instructions on Preparation of Chips (P3)

*this is for Sandwich Topping Compatibility*

<table>
  <thead>
    <tr>
      <th>Brand</th>
      <th>Sandwich</th>
      <th>Coffee</th>
      <th>Other</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Frito</td>
      <td>+$2.00</td>
      <td>+$3.00</td>
      <td>+$2.00*</td>
    </tr>
    <tr>
      <td>Lays</td>
      <td>+$1.50</td>
      <td>+$3.00</td>
      <td>+$2.09</td>
    </tr>
    <tr>
      <td>Juantonios</td>
      <td>+$1.00</td>
      <td>+$2.75*</td>
      <td>+$2.50</td>
    </tr>
    <tr>
      <td>[OTHER]</td>
      <td>+$0.00</td>
      <td>+$2.50</td>
      <td>NA</td>
    </tr>
  </tbody>
</table>

NOTE: *Free Drink