

# Bodega Test Page 2
## Instructions on Preparation of Sandwich (P2)

*this is for Sandwich Topping Compatibility*

<table>
  <thead>
    <tr>
      <th></th>
      <th>BLT</th>
      <th>Club</th>
      <th>Ruben</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Mayo</td>
      <td>TRUE</td>
      <td>TRUE</td>
      <td>TRUE</td>
    </tr>
    <tr>
      <td>Mustard</td>
      <td>TRUE</td>
      <td>FALSE</td>
      <td>FALSE</td>
    </tr>
    <tr>
      <td>Salt & Pepper</td>
      <td>TRUE</td>
      <td>TRUE</td>
      <td>FALSE</td>
    </tr>
    <tr>
      <td>[PLACEHOLDER]</td>
      <td>TRUE</td>
      <td>TRUE</td>
      <td>TRUE</td>
    </tr>
  </tbody>
</table>

**NOTE:** NA