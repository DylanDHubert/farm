

# Bodega Test Page 4
## Instructions on Preparation of Chips (P3)

*this is for Sandwich Topping Compatibility*

<table>
<thead>
<tr>
<th colspan="2">[SMALL DRINKS]</th>
</tr>
<tr>
<th>Drink Name</th>
<th>ID</th>
</tr>
</thead>
<tbody>
<tr>
<td>Coke</td>
<td>04182003</td>
</tr>
<tr>
<td>Pepsi</td>
<td>10252005</td>
</tr>
<tr>
<td>Dr. Pepper</td>
<td>11221969</td>
</tr>
</tbody>
</table>

<table>
<thead>
<tr>
<th colspan="2">[MD-LG+ DRINKS]</th>
</tr>
<tr>
<th>Drink Name</th>
<th>ID</th>
</tr>
</thead>
<tbody>
<tr>
<td>Coke</td>
<td>04182004</td>
</tr>
<tr>
<td>Pepsi</td>
<td>10252006</td>
</tr>
<tr>
<td>Dr. Pepper</td>
<td>11221970</td>
</tr>
<tr>
<td>Spite</td>
<td>04071963</td>
</tr>
</tbody>
</table>

**NOTE:** *Spite not available for Sm.*

LEFT TABLE FOR SMALL DRINKS
RIGHT TABLE FOR MED+