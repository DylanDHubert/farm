

# Bodega Test Page 1
## Instructions on Preparation of Sandwich

*this is for B.L.T. (Bacon Lettuce Tomato)*

<table>
  <thead>
    <tr>
      <th>(Oz)</th>
      <th>B</th>
      <th>L</th>
      <th>T</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Small</td>
      <td>0.5</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <td>Medium</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <td>Large</td>
      <td>2.5</td>
      <td>3</td>
      <td>2</td>
    </tr>
  </tbody>
</table>

**NOTE:** Mayo Optional